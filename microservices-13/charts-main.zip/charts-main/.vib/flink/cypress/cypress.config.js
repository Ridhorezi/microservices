module.exports = {
  defaultCommandTimeout: 90000,
  e2e: {
    setupNodeEvents(on, config) {},
    baseUrl: 'http://localhost',
  },
}
