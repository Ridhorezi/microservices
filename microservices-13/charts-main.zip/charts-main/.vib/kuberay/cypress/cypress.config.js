module.exports = {
  pageLoadTimeout: 240000,
  defaultCommandTimeout: 80000,
  e2e: {
    setupNodeEvents(on, config) {},
    baseUrl: 'http://localhost',
  },
}
